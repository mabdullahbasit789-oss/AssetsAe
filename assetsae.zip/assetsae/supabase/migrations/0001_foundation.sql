-- AssetsAe foundation schema.
-- Principles: collect only what is needed, deny by default (RLS on every table),
-- users can only touch their own rows, publishing and featuring are admin-only.
-- Admin work (publishing, featuring, licenses) uses the service role or the Supabase dashboard.

-- ---------------------------------------------------------------------------
-- Enums
-- ---------------------------------------------------------------------------
create type public.asset_category as enum
  ('clips', 'overlays', 'effects', 'presets', 'luts', 'templates', 'audio', 'stickers', 'other');

create type public.asset_status as enum ('draft', 'in_review', 'published', 'archived');

create type public.tutorial_track as enum
  ('after_effects', 'alight_motion', 'editing_techniques', 'effects_tutorials', 'color_grading');

create type public.creation_kind as enum ('effect', 'preset', 'style_analysis', 'other');

create type public.consent_kind as enum ('terms', 'privacy', 'marketing_email', 'analytics_cookies');

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------
create function public.set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

-- ---------------------------------------------------------------------------
-- Profiles (one per auth user). Minimal by design.
-- ---------------------------------------------------------------------------
create table public.profiles (
  id           uuid primary key references auth.users (id) on delete cascade,
  username     text unique check (username ~ '^[a-z0-9_]{3,30}$'),
  display_name text check (char_length(display_name) <= 80),
  bio          text check (char_length(bio) <= 500),
  avatar_path  text,
  youtube_url  text check (youtube_url is null or youtube_url ~ '^https://'),
  is_creator   boolean not null default false,  -- set by admins
  is_featured  boolean not null default false,  -- set by admins
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create trigger profiles_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();

alter table public.profiles enable row level security;

-- You can read your own profile; everyone can read creator profiles.
create policy "profiles: read own or creators" on public.profiles
  for select using (id = auth.uid() or is_creator);
create policy "profiles: update own" on public.profiles
  for update using (id = auth.uid()) with check (id = auth.uid());

-- Column-level grants keep users from granting themselves creator or featured status.
revoke update on public.profiles from authenticated;
grant update (username, display_name, bio, avatar_path, youtube_url) on public.profiles to authenticated;

-- ---------------------------------------------------------------------------
-- Licenses. Every asset must reference one.
-- ---------------------------------------------------------------------------
create table public.licenses (
  id                    uuid primary key default gen_random_uuid(),
  slug                  text not null unique,
  name                  text not null,
  summary               text,
  terms_url             text check (terms_url is null or terms_url ~ '^https://'),
  allows_commercial_use boolean not null,
  requires_attribution  boolean not null default false,
  created_at            timestamptz not null default now()
);
alter table public.licenses enable row level security;
create policy "licenses: public read" on public.licenses for select using (true);

-- ---------------------------------------------------------------------------
-- Assets
-- ---------------------------------------------------------------------------
create table public.assets (
  id              uuid primary key default gen_random_uuid(),
  slug            text not null,
  title           text not null check (char_length(title) between 3 and 120),
  description     text check (char_length(description) <= 2000),
  category        public.asset_category not null,
  status          public.asset_status not null default 'draft',
  is_featured     boolean not null default false,
  creator_id      uuid not null references public.profiles (id) on delete cascade,
  license_id      uuid not null references public.licenses (id),
  software        text[] not null default '{}',
  tags            text[] not null default '{}',
  preview_path    text,   -- object path in the public asset-previews bucket
  file_path       text,   -- object path in the private asset-files bucket
  file_size_bytes bigint check (file_size_bytes is null or file_size_bytes >= 0),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  published_at    timestamptz,
  unique (category, slug)
);
create index assets_category_published_idx on public.assets (category, published_at desc) where status = 'published';
create index assets_featured_idx on public.assets (published_at desc) where status = 'published' and is_featured;
create index assets_creator_idx on public.assets (creator_id);
create trigger assets_updated_at before update on public.assets
  for each row execute function public.set_updated_at();

alter table public.assets enable row level security;

create policy "assets: public read published" on public.assets
  for select using (status = 'published');
create policy "assets: creators read own" on public.assets
  for select using (creator_id = auth.uid());
create policy "assets: creators insert own drafts" on public.assets
  for insert with check (
    creator_id = auth.uid()
    and status in ('draft', 'in_review')
    and exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_creator)
  );
create policy "assets: creators update own unpublished" on public.assets
  for update using (creator_id = auth.uid() and status in ('draft', 'in_review'))
  with check (creator_id = auth.uid() and status in ('draft', 'in_review'));
create policy "assets: creators delete own unpublished" on public.assets
  for delete using (creator_id = auth.uid() and status in ('draft', 'in_review'));

-- Only admins (service role) can publish or feature.
revoke insert, update on public.assets from authenticated;
grant insert (slug, title, description, category, status, creator_id, license_id, software, tags,
              preview_path, file_path, file_size_bytes) on public.assets to authenticated;
grant update (slug, title, description, category, status, license_id, software, tags,
              preview_path, file_path, file_size_bytes) on public.assets to authenticated;

-- ---------------------------------------------------------------------------
-- Cloud library
-- ---------------------------------------------------------------------------
create table public.saved_assets (
  user_id  uuid not null references public.profiles (id) on delete cascade,
  asset_id uuid not null references public.assets (id) on delete cascade,
  saved_at timestamptz not null default now(),
  primary key (user_id, asset_id)
);
alter table public.saved_assets enable row level security;
create policy "saved_assets: own" on public.saved_assets
  for all using (user_id = auth.uid()) with check (user_id = auth.uid());

create table public.downloads (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references public.profiles (id) on delete cascade,
  asset_id      uuid not null references public.assets (id) on delete cascade,
  license_id    uuid not null references public.licenses (id), -- license in force at download time
  downloaded_at timestamptz not null default now()
);
create index downloads_user_idx on public.downloads (user_id, downloaded_at desc);
alter table public.downloads enable row level security;
create policy "downloads: read own" on public.downloads for select using (user_id = auth.uid());
create policy "downloads: insert own" on public.downloads for insert with check (user_id = auth.uid());

create table public.collections (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.profiles (id) on delete cascade,
  name        text not null check (char_length(name) between 1 and 80),
  description text check (char_length(description) <= 500),
  is_public   boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create trigger collections_updated_at before update on public.collections
  for each row execute function public.set_updated_at();
alter table public.collections enable row level security;
create policy "collections: own" on public.collections
  for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "collections: public read" on public.collections
  for select using (is_public);

create table public.collection_items (
  collection_id uuid not null references public.collections (id) on delete cascade,
  asset_id      uuid not null references public.assets (id) on delete cascade,
  added_at      timestamptz not null default now(),
  primary key (collection_id, asset_id)
);
alter table public.collection_items enable row level security;
create policy "collection_items: owner manages" on public.collection_items
  for all using (exists (select 1 from public.collections c where c.id = collection_id and c.user_id = auth.uid()))
  with check (exists (select 1 from public.collections c where c.id = collection_id and c.user_id = auth.uid()));
create policy "collection_items: public read" on public.collection_items
  for select using (exists (select 1 from public.collections c where c.id = collection_id and c.is_public));

create table public.user_creations (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.profiles (id) on delete cascade,
  kind       public.creation_kind not null,
  title      text not null check (char_length(title) between 1 and 120),
  payload    jsonb not null default '{}'::jsonb,  -- tool output; schema per kind, versioned in the app
  created_at timestamptz not null default now()
);
create index user_creations_user_idx on public.user_creations (user_id, created_at desc);
alter table public.user_creations enable row level security;
create policy "user_creations: own" on public.user_creations
  for all using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ---------------------------------------------------------------------------
-- Learning center
-- ---------------------------------------------------------------------------
create table public.tutorials (
  id           uuid primary key default gen_random_uuid(),
  slug         text not null unique,
  track        public.tutorial_track not null,
  title        text not null,
  summary      text not null,
  body_path    text,                              -- content stored in Storage or a CMS later
  author_id    uuid references public.profiles (id) on delete set null,
  status       public.asset_status not null default 'draft',
  published_at timestamptz,
  created_at   timestamptz not null default now()
);
create index tutorials_track_idx on public.tutorials (track, published_at desc) where status = 'published';
alter table public.tutorials enable row level security;
create policy "tutorials: public read published" on public.tutorials
  for select using (status = 'published');

-- Which assets a tutorial uses, so lessons can link to them.
create table public.tutorial_assets (
  tutorial_id uuid not null references public.tutorials (id) on delete cascade,
  asset_id    uuid not null references public.assets (id) on delete cascade,
  primary key (tutorial_id, asset_id)
);
alter table public.tutorial_assets enable row level security;
create policy "tutorial_assets: public read" on public.tutorial_assets for select using (true);

-- ---------------------------------------------------------------------------
-- Consent records: append-only proof of what the user agreed to.
-- ---------------------------------------------------------------------------
create table public.consent_records (
  id               uuid primary key default gen_random_uuid(),
  user_id          uuid not null references public.profiles (id) on delete cascade,
  kind             public.consent_kind not null,
  granted          boolean not null,
  document_version text not null,
  created_at       timestamptz not null default now()
);
create index consent_records_user_idx on public.consent_records (user_id, created_at desc);
alter table public.consent_records enable row level security;
create policy "consent_records: read own" on public.consent_records for select using (user_id = auth.uid());
create policy "consent_records: insert own" on public.consent_records for insert with check (user_id = auth.uid());
-- No update or delete policies: records are append-only (they are removed when the account is deleted).

-- ---------------------------------------------------------------------------
-- New user hook: create the profile and record the consent given at sign-up.
-- Marketing opt-in is only recorded when the user ticked the box (default is off).
-- ---------------------------------------------------------------------------
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = '' as $$
declare
  terms_version text := new.raw_user_meta_data ->> 'terms_version';
begin
  insert into public.profiles (id) values (new.id);

  if terms_version is not null then
    insert into public.consent_records (user_id, kind, granted, document_version) values
      (new.id, 'terms',   true, terms_version),
      (new.id, 'privacy', true, terms_version);
  end if;

  if coalesce(new.raw_user_meta_data ->> 'marketing_opt_in', 'false') = 'true' then
    insert into public.consent_records (user_id, kind, granted, document_version)
    values (new.id, 'marketing_email', true, coalesce(terms_version, 'unknown'));
  end if;

  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------------
-- Storage buckets and policies.
-- Convention: every object path starts with the owner's user id: "<uid>/<file>".
-- asset-files is private: downloads go through signed URLs created server-side.
-- ---------------------------------------------------------------------------
insert into storage.buckets (id, name, public) values
  ('asset-previews', 'asset-previews', true),
  ('asset-files',    'asset-files',    false),
  ('avatars',        'avatars',        true)
on conflict (id) do nothing;

create policy "previews: creators upload to own folder" on storage.objects
  for insert to authenticated with check (
    bucket_id = 'asset-previews' and (storage.foldername(name))[1] = auth.uid()::text
    and exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_creator)
  );
create policy "previews: creators manage own" on storage.objects
  for update to authenticated using (bucket_id = 'asset-previews' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "previews: creators delete own" on storage.objects
  for delete to authenticated using (bucket_id = 'asset-previews' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "asset files: creators upload to own folder" on storage.objects
  for insert to authenticated with check (
    bucket_id = 'asset-files' and (storage.foldername(name))[1] = auth.uid()::text
    and exists (select 1 from public.profiles p where p.id = auth.uid() and p.is_creator)
  );
create policy "asset files: creators read own" on storage.objects
  for select to authenticated using (bucket_id = 'asset-files' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "asset files: creators delete own" on storage.objects
  for delete to authenticated using (bucket_id = 'asset-files' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "avatars: users upload to own folder" on storage.objects
  for insert to authenticated with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "avatars: users update own" on storage.objects
  for update to authenticated using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "avatars: users delete own" on storage.objects
  for delete to authenticated using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
