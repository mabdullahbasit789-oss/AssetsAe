import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { BUCKETS } from "@/lib/storage";

export const runtime = "nodejs";

/**
 * Permanently deletes the signed-in user's account and data.
 * Database rows cascade from auth.users. Storage objects do not, so they are removed here first.
 * Objects are stored under "<user id>/..." in every bucket.
 */
export async function POST() {
  const supabase = await createClient();
  const admin = createAdminClient();
  if (!supabase || !admin) {
    return NextResponse.json({ error: "Account deletion is not available right now." }, { status: 503 });
  }

  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not signed in." }, { status: 401 });

  for (const bucket of Object.values(BUCKETS)) {
    // List and remove in pages until the user's folder is empty.
    for (;;) {
      const { data: objects, error } = await admin.storage.from(bucket).list(user.id, { limit: 100 });
      if (error) {
        console.error("account delete: list failed", bucket, error.message);
        return NextResponse.json({ error: "Could not remove your files. Nothing was deleted." }, { status: 500 });
      }
      if (!objects || objects.length === 0) break;
      const { error: removeError } = await admin.storage
        .from(bucket)
        .remove(objects.map((o) => `${user.id}/${o.name}`));
      if (removeError) {
        console.error("account delete: remove failed", bucket, removeError.message);
        return NextResponse.json({ error: "Could not remove your files. Nothing was deleted." }, { status: 500 });
      }
    }
  }

  const { error } = await admin.auth.admin.deleteUser(user.id);
  if (error) {
    console.error("account delete: deleteUser failed", error.message);
    return NextResponse.json({ error: "Could not delete your account. Please try again." }, { status: 500 });
  }

  await supabase.auth.signOut();
  return NextResponse.json({ ok: true });
}
