import type { Metadata } from "next";
import { PageHeader } from "@/components/ui/PageHeader";
import { Section } from "@/components/ui/Section";
import { siteConfig, team } from "@/lib/site";

export const metadata: Metadata = {
  title: "About",
  description: "What AssetsAe is, who is building it, and how it handles licensing and your data.",
};

export default function AboutPage() {
  return (
    <>
      <PageHeader title="About AssetsAe" intro="A workspace built by editors, for editors." />

      <Section id="mission" title="What we are building">
        <div className="prose-block">
          <p>
            AssetsAe combines a licensed asset library, AI-assisted editing tools, tutorials and a personal cloud library. The
            aim is to cover the whole workflow: find what you need, know how you are allowed to use it, learn how to use it
            well, and keep it organised.
          </p>
          <p>
            We are starting with the foundation. Features are labeled with their real status, and we will not show numbers,
            reviews or activity that do not exist.
          </p>
        </div>
      </Section>

      <Section id="team" title="Team" intro="Official YouTube channel links will be added here.">
        <div className="team-grid">
          {team.map((member) => (
            <article key={member.name} className="card">
              <p className="card-meta">{member.role}</p>
              <h3>{member.name}</h3>
              <p className="card-description">{member.bio}</p>
              <p className="card-action">
                {member.youtubeUrl ? (
                  <a href={member.youtubeUrl} rel="noopener noreferrer">
                    Visit the official YouTube channel
                  </a>
                ) : (
                  <span className="card-benefit">Official YouTube link coming soon.</span>
                )}
              </p>
            </article>
          ))}
        </div>
      </Section>

      <Section id="trust" title="Licensing and your data">
        <div className="prose-block">
          <p>
            Every asset carries a license that is shown before download. Creators keep their rights, and we only publish assets
            that are properly licensed for distribution.
          </p>
          <p>
            We collect only what an account needs, we never sell personal data, and you can delete your account and data at any
            time from your account page.
          </p>
          {siteConfig.contactEmail ? (
            <p>
              Questions? Email <a href={`mailto:${siteConfig.contactEmail}`}>{siteConfig.contactEmail}</a>.
            </p>
          ) : null}
        </div>
      </Section>
    </>
  );
}
