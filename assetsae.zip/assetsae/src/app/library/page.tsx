import type { Metadata } from "next";
import Link from "next/link";
import { PageHeader } from "@/components/ui/PageHeader";
import { ButtonLink } from "@/components/ui/Button";
import { getLibraryCounts } from "@/lib/data/library";

export const metadata: Metadata = {
  title: "Cloud Library",
  description: "Your saved assets, downloads, creations and collections in one private library.",
};

// The middleware redirects signed-out visitors to /login, and RLS limits every query to the caller's rows.
export default async function LibraryPage() {
  const counts = await getLibraryCounts();

  const sections = [
    {
      id: "saved",
      title: "Saved assets",
      count: counts?.saved,
      description: "Assets you bookmarked to use later.",
      action: { label: "Find assets to save", href: "/assets" },
    },
    {
      id: "downloads",
      title: "Downloads",
      count: counts?.downloads,
      description: "A record of what you downloaded, with the license that applied at the time.",
      action: { label: "Browse assets", href: "/assets" },
    },
    {
      id: "creations",
      title: "Your creations",
      count: counts?.creations,
      description: "Effects, presets and analyses you made with AssetsAe tools.",
      action: { label: "See planned AI tools", href: "/ai-tools" },
    },
    {
      id: "collections",
      title: "Collections",
      count: counts?.collections,
      description: "Groups of assets you organise by project, client or style. Private unless you share them.",
      action: { label: "Find assets for a collection", href: "/assets" },
    },
  ];

  return (
    <>
      <PageHeader
        title="Your cloud library"
        intro="Everything you save, download and create, kept private to your account."
      />
      <section className="section" aria-label="Library overview">
        <div className="container">
          <div className="library-grid">
            {sections.map((s) => (
              <article key={s.id} id={s.id} className="card">
                <h2 style={{ fontSize: "var(--text-lg)" }}>{s.title}</h2>
                <p className="library-count" aria-label={`${s.count ?? 0} items`}>
                  {s.count ?? 0}
                </p>
                <p className="card-description">{s.description}</p>
                <p className="card-action">
                  <Link href={s.action.href}>{s.action.label}</Link>
                </p>
              </article>
            ))}
          </div>
          <div className="section-footer">
            <ButtonLink href="/account/privacy" variant="secondary">
              Manage your data and account
            </ButtonLink>
          </div>
        </div>
      </section>
    </>
  );
}
