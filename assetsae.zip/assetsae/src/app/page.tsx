import Link from "next/link";
import { ButtonLink } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { EmptyState } from "@/components/ui/EmptyState";
import { Section } from "@/components/ui/Section";
import { AssetCard } from "@/components/assets/AssetCard";
import { Timeline } from "@/components/home/Timeline";
import { getFeaturedAssets, getFeaturedCreators } from "@/lib/data/catalog";
import { aiTools, learningTracks } from "@/lib/site";

export default async function HomePage() {
  const [assets, creators] = await Promise.all([getFeaturedAssets(3), getFeaturedCreators(3)]);

  return (
    <>
      <section className="hero" aria-labelledby="hero-heading">
        <div className="container">
          <div className="hero-copy">
            <h1 id="hero-heading">Assets, tools and lessons for video editors</h1>
            <p>
              AssetsAe brings licensed assets, AI-assisted tools, tutorials and a personal cloud library into one workspace, so
              you spend less time searching and more time editing.
            </p>
            <div className="hero-actions">
              <ButtonLink href="/assets">Browse assets</ButtonLink>
              <ButtonLink href="/ai-tools" variant="secondary">
                See the AI tools
              </ButtonLink>
            </div>
            <p className="hero-note">The catalog is new. Assets appear here as creators publish them.</p>
          </div>
          <Timeline />
        </div>
      </section>

      <Section
        id="about"
        title="A workspace, not just a download page"
        intro="Most asset sites stop at the download button. AssetsAe is built around the whole edit: finding the right asset, understanding its license, learning how to use it, and keeping it organised afterwards."
        footer={
          <ButtonLink href="/about" variant="secondary">
            Read about AssetsAe and the team
          </ButtonLink>
        }
      >
        {null}
      </Section>

      <Section
        id="featured-assets"
        title="Featured assets"
        intro="Hand-picked by the AssetsAe team. Every asset shows its license before you download."
        footer={<ButtonLink href="/assets">Browse all categories</ButtonLink>}
      >
        {assets.length > 0 ? (
          <div className="card-grid">
            {assets.map((asset) => (
              <AssetCard key={asset.id} asset={asset} />
            ))}
          </div>
        ) : (
          <EmptyState
            title="No featured assets yet"
            description="Featured assets will appear here once the first licensed packs are published. In the meantime you can see what each category will hold."
            action={{ label: "See asset categories", href: "/assets" }}
          />
        )}
      </Section>

      <Section
        id="featured-creators"
        title="Featured creators"
        intro="Creators who publish on AssetsAe, with links to their official channels."
        footer={<ButtonLink href="/community" variant="secondary">Visit the community page</ButtonLink>}
      >
        {creators.length > 0 ? (
          <div className="card-grid">
            {creators.map((c) => (
              <Card
                key={c.id}
                title={c.displayName ?? c.username ?? "Creator"}
                description={c.bio ?? "Publishes assets on AssetsAe."}
                benefit="Every asset from this creator lists its license."
                action={{ label: "See all creators", href: "/community" }}
              />
            ))}
          </div>
        ) : (
          <EmptyState
            title="Creators will be featured here"
            description="Creator profiles go live with the first published assets. The AssetsAe team is listed on the About page."
            action={{ label: "Meet the team", href: "/about#team" }}
          />
        )}
      </Section>

      <Section
        id="ai-tools"
        title="AI tools for editors"
        intro="Five tools are planned. None are live yet, and each is labeled with its current status so you know what to expect."
        footer={<ButtonLink href="/ai-tools">Read what each tool will do</ButtonLink>}
      >
        <div className="card-grid">
          {aiTools.slice(0, 3).map((tool) => (
            <Card
              key={tool.slug}
              title={tool.name}
              meta={tool.status}
              description={tool.description}
              benefit={tool.benefit}
              action={{ label: `About ${tool.name}`, href: `/ai-tools#${tool.slug}` }}
            />
          ))}
        </div>
      </Section>

      <Section
        id="learn"
        title="Learn the craft"
        intro="Tutorials are organised by tool and by skill, so you can start from what you use or from what you want to improve."
        footer={<ButtonLink href="/learn">See all learning tracks</ButtonLink>}
      >
        <div className="card-grid">
          {learningTracks.slice(0, 3).map((track) => (
            <Card
              key={track.slug}
              title={track.name}
              description={track.description}
              benefit={track.benefit}
              action={{ label: `Open the ${track.name} track`, href: `/learn/${track.slug}` }}
            />
          ))}
        </div>
      </Section>

      <Section
        id="join"
        title="Keep your assets in one place"
        intro="A free account gives you a cloud library for saved assets, downloads and your own creations. We collect only what an account needs. See the Privacy Policy for details."
        footer={
          <>
            <ButtonLink href="/signup">Create a free account</ButtonLink>
          </>
        }
      >
        <p style={{ textAlign: "center", color: "var(--color-text-muted)" }}>
          Already have one? <Link href="/login">Sign in</Link>.
        </p>
      </Section>
    </>
  );
}
