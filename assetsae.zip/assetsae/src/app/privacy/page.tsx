import type { Metadata } from "next";
import Link from "next/link";
import { LegalPage } from "@/components/legal/LegalPage";

export const metadata: Metadata = { title: "Privacy Policy" };

export default function PrivacyPage() {
  return (
    <LegalPage title="Privacy Policy" intro="What we collect, why, who handles it, and how you can delete it.">
      <h2>What we collect</h2>
      <p>We collect only what we need to run your account and the features you use.</p>
      <ul>
        <li>
          <strong>Account data:</strong> your email address and a password. The password is stored hashed by our sign-in
          provider; we cannot read it.
        </li>
        <li>
          <strong>Profile data you choose to add:</strong> display name, username, bio, avatar and a link to your official
          channel.
        </li>
        <li>
          <strong>Library data:</strong> assets you save, your download history, collections, and anything you create with our
          tools.
        </li>
        <li>
          <strong>Uploads:</strong> files you upload as a creator.
        </li>
        <li>
          <strong>Consent records:</strong> which version of the Terms and Privacy Policy you accepted, whether you opted in to
          product emails, and when.
        </li>
      </ul>
      <p>We do not run analytics, advertising or tracking tools at this time.</p>

      <h2>How we use it</h2>
      <ul>
        <li>To create and secure your account and keep you signed in.</li>
        <li>To provide your cloud library and the features you use.</li>
        <li>To send product updates, only if you ticked the optional box. You can withdraw at any time.</li>
        <li>To prove which terms you agreed to.</li>
      </ul>

      <h2>We do not sell your data</h2>
      <p>We do not sell or rent personal data, and we do not share it for advertising.</p>

      <h2>Who handles your data</h2>
      <p>We use a small number of service providers, only where needed to run the site:</p>
      <ul>
        <li>
          <strong>Supabase:</strong> authentication, database and file storage.
        </li>
        <li>
          <strong>Hosting provider:</strong> serves the website. This will be named here when chosen.
        </li>
      </ul>
      <p>Any new provider that handles personal data will be added to this list before it is switched on.</p>

      <h2>How long we keep it</h2>
      <p>
        We keep account data while your account exists. When you delete your account, your profile, library, collections,
        consent records and uploaded files are removed. Backups may retain copies for a limited period before they are
        overwritten. We will state that period here once our hosting setup is final.
      </p>

      <h2>Your choices and rights</h2>
      <ul>
        <li>
          <strong>Delete:</strong> use{" "}
          <Link href="/account/privacy">Your data and account</Link> to delete your account and data yourself at any time.
        </li>
        <li>
          <strong>Access and correction:</strong> you can view and edit your profile in your account. For anything else,
          contact us.
        </li>
        <li>
          <strong>Withdraw consent:</strong> optional email consent can be withdrawn at any time. Cookie choices can be changed
          from &quot;Cookie settings&quot; in the footer.
        </li>
      </ul>
      <p>Depending on where you live, you may have additional rights under local law. Contact us to use them.</p>

      <h2>Security</h2>
      <p>
        Data is encrypted in transit. Access to each user&apos;s library is restricted by database rules so that you can only
        read your own private data. No system is perfectly secure, and we will tell affected users if a breach puts their data
        at risk.
      </p>

      <h2>Children</h2>
      <p>AssetsAe is not directed at children under 13, and we do not knowingly collect their data.</p>

      <h2>Changes</h2>
      <p>If we change this policy in a way that matters, we will update the version date and tell account holders.</p>
    </LegalPage>
  );
}
