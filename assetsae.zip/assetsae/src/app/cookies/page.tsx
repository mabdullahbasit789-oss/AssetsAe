import type { Metadata } from "next";
import { LegalPage } from "@/components/legal/LegalPage";

export const metadata: Metadata = { title: "Cookie Policy" };

const cookies = [
  {
    name: "sb-…-auth-token",
    provider: "AssetsAe (via Supabase Auth)",
    purpose: "Keeps you signed in. Set only after you sign in or create an account.",
    duration: "Session, refreshed while you stay signed in",
    type: "Strictly necessary",
  },
  {
    name: "assetsae_consent",
    provider: "AssetsAe",
    purpose: "Remembers your cookie choice so we do not ask on every visit.",
    duration: "180 days",
    type: "Strictly necessary",
  },
];

export default function CookiePolicyPage() {
  return (
    <LegalPage title="Cookie Policy" intro="Which cookies AssetsAe sets, what they do and how to control them.">
      <h2>Summary</h2>
      <p>
        AssetsAe currently sets only strictly necessary cookies. We do not use analytics, advertising or social media tracking
        cookies.
      </p>

      <h2>Cookies we set</h2>
      <div className="table-wrap">
        <table>
          <caption className="sr-only">Cookies set by AssetsAe</caption>
          <thead>
            <tr>
              <th scope="col">Name</th>
              <th scope="col">Set by</th>
              <th scope="col">Purpose</th>
              <th scope="col">Lifetime</th>
              <th scope="col">Type</th>
            </tr>
          </thead>
          <tbody>
            {cookies.map((c) => (
              <tr key={c.name}>
                <th scope="row">{c.name}</th>
                <td>{c.provider}</td>
                <td>{c.purpose}</td>
                <td>{c.duration}</td>
                <td>{c.type}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <h2>Your choices</h2>
      <p>
        Strictly necessary cookies cannot be switched off in AssetsAe because the site would not work without them. You can
        block cookies in your browser settings, but you will not be able to stay signed in.
      </p>
      <p>
        You can reopen the cookie notice at any time with &quot;Cookie settings&quot; in the footer.
      </p>

      <h2>If this changes</h2>
      <p>
        Before we add any optional cookie or tracking tool, we will list it here and ask for your permission first. Nothing
        optional will load before you agree.
      </p>
    </LegalPage>
  );
}
