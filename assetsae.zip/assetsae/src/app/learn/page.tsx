import type { Metadata } from "next";
import { Card } from "@/components/ui/Card";
import { PageHeader } from "@/components/ui/PageHeader";
import { learningTracks } from "@/lib/site";

export const metadata: Metadata = {
  title: "Learn",
  description: "Tutorials for After Effects, Alight Motion, editing techniques, effects and colour grading.",
};

export default function LearnPage() {
  return (
    <>
      <PageHeader
        title="Learning center"
        intro="Pick a track to see its tutorials. Each lesson links to the assets and project files it uses, so you can follow along."
      />
      <section className="section" aria-label="Learning tracks">
        <div className="container">
          <div className="card-grid">
            {learningTracks.map((t) => (
              <Card
                key={t.slug}
                title={t.name}
                description={t.description}
                benefit={t.benefit}
                action={{ label: `Open the ${t.name} track`, href: `/learn/${t.slug}` }}
              />
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
