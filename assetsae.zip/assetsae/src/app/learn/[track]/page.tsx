import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { EmptyState } from "@/components/ui/EmptyState";
import { PageHeader } from "@/components/ui/PageHeader";
import { getTrack, learningTracks } from "@/lib/site";

type Params = { track: string };

export function generateStaticParams() {
  return learningTracks.map((t) => ({ track: t.slug }));
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const track = getTrack((await params).track);
  return track ? { title: track.name, description: track.description } : {};
}

export default async function TrackPage({ params }: { params: Promise<Params> }) {
  const track = getTrack((await params).track);
  if (!track) notFound();

  // Phase 2: query the `tutorials` table by track.dbValue and render the list here.
  return (
    <>
      <PageHeader title={track.name} intro={`${track.description} ${track.benefit}`} />
      <section className="section" aria-label={`${track.name} tutorials`}>
        <div className="container">
          <EmptyState
            title="No tutorials published yet"
            description="Tutorials in this track will be listed here as they are written. Each will include the project files and assets it uses."
            action={{ label: "Back to all tracks", href: "/learn" }}
          />
        </div>
      </section>
    </>
  );
}
