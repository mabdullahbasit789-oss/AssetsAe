import type { Metadata } from "next";
import Link from "next/link";
import { LegalPage } from "@/components/legal/LegalPage";

export const metadata: Metadata = { title: "Refund Policy" };

export default function RefundsPage() {
  return (
    <LegalPage title="Refund Policy" intro="How refunds will work once AssetsAe sells anything.">
      <h2>Current status</h2>
      <p>
        AssetsAe does not currently take payments, so there is nothing to refund. Accounts and the assets available today are
        free.
      </p>

      <h2>When payments are introduced</h2>
      <p>Before any paid feature or asset goes on sale, this page will be replaced with the full policy. It will state:</p>
      <ul>
        <li>What can be refunded and for how long after purchase.</li>
        <li>How to request a refund and how long it takes.</li>
        <li>What happens to downloaded digital assets, in line with consumer law where you live.</li>
        <li>The total price, including any taxes or fees, shown before you pay.</li>
      </ul>
      <p>
        See also the <Link href="/terms">Terms of Service</Link>.
      </p>
    </LegalPage>
  );
}
