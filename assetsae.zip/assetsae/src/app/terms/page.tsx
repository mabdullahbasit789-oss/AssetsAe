import type { Metadata } from "next";
import Link from "next/link";
import { LegalPage } from "@/components/legal/LegalPage";

export const metadata: Metadata = { title: "Terms of Service" };

export default function TermsPage() {
  return (
    <LegalPage title="Terms of Service" intro="The rules for using AssetsAe, in plain language.">
      <h2>Using AssetsAe</h2>
      <p>
        By creating an account you agree to these terms and confirm you have read the{" "}
        <Link href="/privacy">Privacy Policy</Link>. You must be old enough to form a binding agreement where you live, and at
        least 13 years old.
      </p>

      <h2>Your account</h2>
      <ul>
        <li>Keep your password safe. You are responsible for activity on your account.</li>
        <li>Give accurate information and keep it up to date.</li>
        <li>You can delete your account at any time from your account page.</li>
      </ul>

      <h2>Asset licenses</h2>
      <p>
        Every asset has its own license, shown on the asset page before download. The license, not these terms, decides what
        you may do with that asset, including commercial use and attribution. If an asset shows no license, do not use it.
      </p>

      <h2>Content you upload</h2>
      <ul>
        <li>You keep ownership of what you upload.</li>
        <li>
          You confirm you own it or have the right to share it, and that you are not infringing anyone&apos;s rights.
        </li>
        <li>
          You give AssetsAe permission to host and display it, and to make it available under the license you chose, for as
          long as it is published.
        </li>
        <li>We may remove content that breaks these terms or the law, or that is the subject of a valid rights complaint.</li>
      </ul>

      <h2>Acceptable use</h2>
      <ul>
        <li>Do not upload content you do not have rights to, or that is unlawful, hateful or harmful.</li>
        <li>Do not resell or redistribute assets in a way their license forbids.</li>
        <li>Do not attempt to break, overload or gain unauthorised access to the service.</li>
      </ul>

      <h2>AI tools</h2>
      <p>
        AI tools may produce inaccurate or unsuitable results. Check outputs before relying on them. The rules for what we do
        with anything you submit to an AI tool will be set out in the Privacy Policy before any tool launches.
      </p>

      <h2>Payments</h2>
      <p>
        AssetsAe does not currently take payments. If that changes, prices and fees will be shown in full before you pay, and
        the <Link href="/refunds">Refund Policy</Link> will apply.
      </p>

      <h2>Ending your use</h2>
      <p>
        You can stop using AssetsAe at any time. We may suspend or close accounts that seriously or repeatedly break these
        terms, and we will explain why when we do.
      </p>

      <h2>Disclaimers and liability</h2>
      <p>
        The service is provided as is, and we do not promise it will always be available or error free. To the extent the law
        allows, AssetsAe is not liable for indirect or consequential loss. Nothing here limits rights you have under law that
        cannot be limited.
      </p>

      <h2>Changes</h2>
      <p>
        If we change these terms in a way that matters, we will update the version date and ask for your agreement again where
        the law requires it.
      </p>
    </LegalPage>
  );
}
