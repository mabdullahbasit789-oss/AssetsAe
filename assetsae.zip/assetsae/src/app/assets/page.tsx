import type { Metadata } from "next";
import { Card } from "@/components/ui/Card";
import { PageHeader } from "@/components/ui/PageHeader";
import { assetCategories } from "@/lib/site";

export const metadata: Metadata = {
  title: "Assets",
  description: "Browse licensed video clips, overlays, effects, presets, LUTs, templates, audio and more.",
};

export default function AssetsPage() {
  return (
    <>
      <PageHeader
        title="Assets library"
        intro="Choose a category to browse. Every asset lists its license, compatible software and creator before you download."
      />
      <section className="section" aria-label="Asset categories">
        <div className="container">
          <div className="card-grid">
            {assetCategories.map((c) => (
              <Card
                key={c.slug}
                title={c.name}
                description={c.description}
                benefit={c.benefit}
                action={{ label: `Browse ${c.name.toLowerCase()}`, href: `/assets/${c.slug}` }}
              />
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
