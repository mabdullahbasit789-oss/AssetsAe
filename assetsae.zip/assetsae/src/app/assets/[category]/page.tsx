import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { AssetCard } from "@/components/assets/AssetCard";
import { EmptyState } from "@/components/ui/EmptyState";
import { PageHeader } from "@/components/ui/PageHeader";
import { getAssetsByCategory } from "@/lib/data/catalog";
import { assetCategories, getCategory, type AssetCategorySlug } from "@/lib/site";

type Params = { category: string };

export function generateStaticParams() {
  return assetCategories.map((c) => ({ category: c.slug }));
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const category = getCategory((await params).category);
  return category ? { title: category.name, description: category.description } : {};
}

export default async function CategoryPage({ params }: { params: Promise<Params> }) {
  const category = getCategory((await params).category);
  if (!category) notFound();

  const assets = await getAssetsByCategory(category.slug as AssetCategorySlug);

  return (
    <>
      <PageHeader title={category.name} intro={`${category.description} ${category.benefit}`} />
      <section className="section" aria-label={`${category.name} assets`}>
        <div className="container">
          {assets.length > 0 ? (
            <div className="card-grid">
              {assets.map((a) => (
                <AssetCard key={a.id} asset={a} />
              ))}
            </div>
          ) : (
            <EmptyState
              title={`No ${category.name.toLowerCase()} published yet`}
              description="Assets appear here after they pass review and have a license attached. Browse another category in the meantime."
              action={{ label: "Back to all categories", href: "/assets" }}
            />
          )}
        </div>
      </section>
    </>
  );
}
