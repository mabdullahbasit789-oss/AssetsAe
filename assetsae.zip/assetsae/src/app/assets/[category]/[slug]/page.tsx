import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHeader } from "@/components/ui/PageHeader";
import { getAsset } from "@/lib/data/catalog";
import { getCategory, type AssetCategorySlug } from "@/lib/site";

type Params = { category: string; slug: string };

async function load(params: Promise<Params>) {
  const { category: categorySlug, slug } = await params;
  const category = getCategory(categorySlug);
  if (!category) return null;
  const asset = await getAsset(category.slug as AssetCategorySlug, slug);
  return asset ? { asset, category } : null;
}

export async function generateMetadata({ params }: { params: Promise<Params> }): Promise<Metadata> {
  const found = await load(params);
  return found ? { title: found.asset.title, description: found.asset.description } : {};
}

export default async function AssetPage({ params }: { params: Promise<Params> }) {
  const found = await load(params);
  if (!found) notFound();
  const { asset, category } = found;
  const creatorName = asset.creator?.displayName ?? asset.creator?.username;

  return (
    <>
      <PageHeader title={asset.title} intro={asset.description} />
      <div className="container">
        <article className="detail">
          {asset.previewUrl ? (
            <Image
              src={asset.previewUrl}
              alt={`Preview of ${asset.title}`}
              width={1280}
              height={720}
              style={{ width: "100%", height: "auto", borderRadius: "var(--radius-lg)" }}
              priority
            />
          ) : null}

          <section aria-labelledby="details-heading">
            <h2 id="details-heading">Details</h2>
            <dl className="detail-meta">
              <dt>Category</dt>
              <dd>
                <Link href={`/assets/${category.slug}`}>{category.name}</Link>
              </dd>
              {creatorName ? (
                <>
                  <dt>Creator</dt>
                  <dd>{creatorName}</dd>
                </>
              ) : null}
              {asset.software.length > 0 ? (
                <>
                  <dt>Works with</dt>
                  <dd>{asset.software.join(", ")}</dd>
                </>
              ) : null}
            </dl>
          </section>

          <section aria-labelledby="license-heading">
            <h2 id="license-heading">License</h2>
            {asset.license ? (
              <>
                <p>
                  <strong>{asset.license.name}</strong>
                  {asset.license.summary ? `: ${asset.license.summary}` : null}
                </p>
                {asset.license.termsUrl ? (
                  <p>
                    <a href={asset.license.termsUrl} rel="noopener noreferrer">
                      Read the full license terms
                    </a>
                  </p>
                ) : null}
              </>
            ) : (
              <p>No license is attached to this asset. Do not use it until one is listed.</p>
            )}
          </section>

          <p style={{ color: "var(--color-text-muted)" }}>
            Saving and downloading are added in the next phase. <Link href="/signup">Create an account</Link> to be ready when
            they launch.
          </p>
        </article>
      </div>
    </>
  );
}
