import type { Metadata } from "next";
import Link from "next/link";
import { DeleteAccountForm } from "@/components/auth/DeleteAccountForm";
import { PageHeader } from "@/components/ui/PageHeader";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = { title: "Your data and account" };

export default async function AccountPrivacyPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = supabase ? await supabase.auth.getUser() : { data: { user: null } };

  return (
    <>
      <PageHeader
        title="Your data and account"
        intro="See what we hold and delete it whenever you like."
      />
      <div className="container">
        <div className="legal">
          <h2>What we hold</h2>
          <ul>
            <li>Your email address{user?.email ? ` (${user.email})` : ""} and a hashed password, managed by our sign-in provider.</li>
            <li>Your profile, library, collections and the consent choices you made.</li>
            <li>Files you uploaded, if any.</li>
          </ul>
          <p>
            Details of how we use this are in the <Link href="/privacy">Privacy Policy</Link>. We do not sell your data.
          </p>

          <h2>Delete your account</h2>
          <DeleteAccountForm />
        </div>
      </div>
    </>
  );
}
