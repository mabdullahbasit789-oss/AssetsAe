import { EmptyState } from "@/components/ui/EmptyState";

export default function NotFound() {
  return (
    <section className="section">
      <div className="container">
        <EmptyState
          title="That page could not be found"
          description="The link may be old, or the page may have moved. Try the assets library instead."
          action={{ label: "Go to assets", href: "/assets" }}
        />
      </div>
    </section>
  );
}
