import type { Metadata } from "next";
import { Card } from "@/components/ui/Card";
import { EmptyState } from "@/components/ui/EmptyState";
import { PageHeader } from "@/components/ui/PageHeader";
import { Section } from "@/components/ui/Section";
import { getFeaturedCreators } from "@/lib/data/catalog";

export const metadata: Metadata = {
  title: "Community",
  description: "Creators who publish assets and tutorials on AssetsAe.",
};

export default async function CommunityPage() {
  const creators = await getFeaturedCreators(24);

  return (
    <>
      <PageHeader
        title="Creator community"
        intro="The editors behind the assets and tutorials. Every creator links to their own official channels."
      />
      <Section id="creators" title="Featured creators">
        {creators.length > 0 ? (
          <div className="card-grid">
            {creators.map((c) => (
              <Card
                key={c.id}
                title={c.displayName ?? c.username ?? "Creator"}
                description={c.bio ?? "Publishes assets on AssetsAe."}
                benefit="Every asset from this creator lists its license."
                action={
                  c.youtubeUrl
                    ? { label: "Visit their official YouTube channel", href: c.youtubeUrl }
                    : { label: "Browse all assets", href: "/assets" }
                }
              />
            ))}
          </div>
        ) : (
          <EmptyState
            title="No creators listed yet"
            description="Creator profiles appear here when their first asset is published. Community features such as following and comments are not part of this phase."
            action={{ label: "Meet the AssetsAe team", href: "/about#team" }}
          />
        )}
      </Section>
    </>
  );
}
