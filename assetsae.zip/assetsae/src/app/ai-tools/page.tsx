import type { Metadata } from "next";
import Link from "next/link";
import { PageHeader } from "@/components/ui/PageHeader";
import { aiTools } from "@/lib/site";

export const metadata: Metadata = {
  title: "AI Tools",
  description: "Planned AI tools for editors: effect creation, preset conversion, style analysis, asset search and an editing assistant.",
};

export default function AiToolsPage() {
  return (
    <>
      <PageHeader
        title="AI tools"
        intro="Five tools are planned. None are available yet. Each one below says what it will do, why it helps, and where it stands today."
      />
      <section className="section" aria-label="Planned AI tools">
        <div className="container">
          <div className="card-grid">
            {aiTools.map((tool) => (
              <article key={tool.slug} id={tool.slug} className="card">
                <p className="card-meta">{tool.status}</p>
                <h2 style={{ fontSize: "var(--text-lg)" }}>{tool.name}</h2>
                <p className="card-description">{tool.description}</p>
                <p className="card-benefit">{tool.benefit}</p>
                <p className="card-action">
                  <Link href="/signup">Create an account to use it when it launches</Link>
                </p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="ai-principles">
        <div className="container">
          <div className="prose-block">
            <h2 id="ai-principles">How the AI will behave</h2>
            <p>
              The AssetsAe assistant is meant to feel like an editor friend: helpful and professional first, with the odd
              editing joke when it fits. It will never insult you, never invent assets or reviews, and will always tell you to
              check an asset&apos;s license before commercial use.
            </p>
            <p>
              Anything you upload to an AI tool will be used only to run that tool for you, and the Privacy Policy will be
              updated to say exactly how before any tool launches.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
