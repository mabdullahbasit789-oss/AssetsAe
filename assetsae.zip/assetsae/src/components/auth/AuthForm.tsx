"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useId, useState, type FormEvent } from "react";
import { createClient } from "@/lib/supabase/client";
import { siteConfig } from "@/lib/site";
import { Button } from "@/components/ui/Button";

type Props = { mode: "login" | "signup"; next?: string };
type Message = { kind: "error" | "success"; text: string } | null;

/** Only allow same-site relative redirects. */
function safeNext(next?: string) {
  return next && next.startsWith("/") && !next.startsWith("//") ? next : "/library";
}

export function AuthForm({ mode, next }: Props) {
  const router = useRouter();
  const id = useId();
  const [message, setMessage] = useState<Message>(null);
  const [busy, setBusy] = useState(false);
  const isSignup = mode === "signup";

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessage(null);
    const form = new FormData(event.currentTarget);
    const email = String(form.get("email") ?? "").trim();
    const password = String(form.get("password") ?? "");

    // Consent is never assumed: both boxes start unchecked and the terms box is required.
    if (isSignup && form.get("terms") !== "on") {
      setMessage({ kind: "error", text: "Please agree to the Terms of Service and Privacy Policy to create an account." });
      return;
    }

    setBusy(true);
    try {
      const supabase = createClient();
      if (isSignup) {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/auth/callback?next=${encodeURIComponent(safeNext(next))}`,
            // Read by the database trigger that writes consent_records.
            data: { terms_version: siteConfig.legalVersion, marketing_opt_in: form.get("marketing") === "on" },
          },
        });
        if (error) throw error;
        if (data.session) {
          router.push(safeNext(next));
          router.refresh();
        } else {
          setMessage({ kind: "success", text: "Check your email for a confirmation link to finish creating your account." });
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        router.push(safeNext(next));
        router.refresh();
      }
    } catch (err) {
      setMessage({ kind: "error", text: err instanceof Error ? err.message : "Something went wrong. Please try again." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="form-panel">
      <h1 style={{ fontSize: "var(--text-2xl)" }}>{isSignup ? "Create your account" : "Sign in"}</h1>
      <p>
        {isSignup
          ? "We ask for your email and a password. That is all an account needs."
          : "Welcome back. Enter your email and password."}
      </p>

      <form className="form" onSubmit={onSubmit} noValidate={false}>
        <div className="field">
          <label htmlFor={`${id}-email`}>Email address</label>
          <input id={`${id}-email`} name="email" type="email" className="input" autoComplete="email" required />
        </div>

        <div className="field">
          <label htmlFor={`${id}-password`}>Password</label>
          <input
            id={`${id}-password`}
            name="password"
            type="password"
            className="input"
            autoComplete={isSignup ? "new-password" : "current-password"}
            minLength={isSignup ? 8 : undefined}
            aria-describedby={isSignup ? `${id}-password-hint` : undefined}
            required
          />
          {isSignup ? (
            <p id={`${id}-password-hint`} className="field-hint">
              At least 8 characters.
            </p>
          ) : null}
        </div>

        {isSignup ? (
          <fieldset className="field" style={{ border: 0, padding: 0, margin: 0 }}>
            <legend className="sr-only">Agreements</legend>
            <div className="check">
              <input id={`${id}-terms`} name="terms" type="checkbox" required />
              <label htmlFor={`${id}-terms`}>
                I agree to the <Link href="/terms">Terms of Service</Link> and have read the{" "}
                <Link href="/privacy">Privacy Policy</Link>. (Required)
              </label>
            </div>
            <div className="check">
              <input id={`${id}-marketing`} name="marketing" type="checkbox" />
              <label htmlFor={`${id}-marketing`}>
                Email me occasional product updates. (Optional)
                <small>You can turn this off at any time. It does not affect your account.</small>
              </label>
            </div>
          </fieldset>
        ) : null}

        <div role="status" aria-live="polite">
          {message ? (
            <p className="form-message" data-kind={message.kind}>
              {message.text}
            </p>
          ) : null}
        </div>

        <Button type="submit" disabled={busy}>
          {busy ? "Please wait" : isSignup ? "Create account" : "Sign in"}
        </Button>
      </form>

      <p>
        {isSignup ? (
          <>
            Already have an account? <Link href="/login">Sign in</Link>
          </>
        ) : (
          <>
            New to AssetsAe? <Link href="/signup">Create an account</Link>
          </>
        )}
      </p>
    </div>
  );
}
