"use client";

import { useRouter } from "next/navigation";
import { useId, useState, type FormEvent } from "react";
import { Button } from "@/components/ui/Button";

export function DeleteAccountForm() {
  const router = useRouter();
  const id = useId();
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/account/delete", { method: "POST" });
      if (!res.ok) {
        const body = (await res.json().catch(() => ({}))) as { error?: string };
        throw new Error(body.error ?? "Could not delete your account.");
      }
      router.push("/");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not delete your account.");
      setBusy(false);
    }
  }

  return (
    <form className="form" onSubmit={onSubmit}>
      <div className="field">
        <label htmlFor={`${id}-confirm`}>Type DELETE to confirm</label>
        <input
          id={`${id}-confirm`}
          className="input"
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
          autoComplete="off"
          aria-describedby={`${id}-hint`}
        />
        <p id={`${id}-hint`} className="field-hint">
          This permanently removes your profile, library, collections, consent records and uploaded files. It cannot be undone.
        </p>
      </div>
      <div role="alert">{error ? <p className="form-message" data-kind="error">{error}</p> : null}</div>
      <Button type="submit" variant="danger" disabled={confirm !== "DELETE" || busy}>
        {busy ? "Deleting" : "Permanently delete my account"}
      </Button>
    </form>
  );
}
