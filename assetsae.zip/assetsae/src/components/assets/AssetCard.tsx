import Image from "next/image";
import { Card } from "@/components/ui/Card";
import { assetCategories } from "@/lib/site";
import type { Asset } from "@/types/domain";

/** One published asset. Shows its license up front, as the licensing rules require. */
export function AssetCard({ asset }: { asset: Asset }) {
  const category = assetCategories.find((c) => c.slug === asset.category);
  const by = asset.creator?.displayName ?? asset.creator?.username;
  const parts = [
    category?.name,
    by ? `by ${by}` : null,
    asset.license ? `License: ${asset.license.name}` : "License: see asset page",
  ].filter(Boolean);

  return (
    <Card
      title={asset.title}
      meta={parts.join(" · ")}
      description={asset.description || `A ${category?.name.toLowerCase() ?? "creative"} asset.`}
      benefit={
        asset.software.length > 0
          ? `Works with ${asset.software.join(", ")}.`
          : "Check the asset page for compatible software."
      }
      action={{ label: `View ${asset.title}`, href: `/assets/${asset.category}/${asset.slug}` }}
      media={
        asset.previewUrl ? (
          <Image
            src={asset.previewUrl}
            alt={`Preview of ${asset.title}, a ${category?.name.toLowerCase() ?? "creative"} asset`}
            fill
            sizes="(min-width: 768px) 33vw, 100vw"
          />
        ) : undefined
      }
    />
  );
}
