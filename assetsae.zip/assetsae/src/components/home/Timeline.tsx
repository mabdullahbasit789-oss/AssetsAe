/**
 * Hero illustration: a simplified editing timeline. The accent playhead sweeps
 * across once and lights the clips it passes. It is the single bright moment
 * on the page; everything else stays neutral.
 */

const TRACKS = [
  { label: "Clips", y: 24, clips: [[120, 220], [350, 150], [510, 270]] },
  { label: "Overlays", y: 76, clips: [[200, 160], [420, 200]] },
  { label: "Effects", y: 128, clips: [[150, 110], [330, 90], [560, 190]] },
  { label: "Audio", y: 180, clips: [[120, 400], [540, 260]] },
] as const;

// Clips the playhead crosses (start x between 140 and 700) light up as it passes.
// Delay is derived from position so the highlight follows the playhead.
function litDelay(x: number) {
  const progress = (x - 140) / 560; // 0..1 across the sweep
  return 0.5 + progress * 2.6;
}

export function Timeline() {
  return (
    <div className="timeline">
      <svg
        viewBox="0 0 960 240"
        role="img"
        aria-label="An editing timeline with four tracks: clips, overlays, effects and audio. A playhead moves across them."
      >
        {TRACKS.map((track) => (
          <g key={track.label}>
            <rect className="tl-track" x="104" y={track.y} width="832" height="44" rx="4" />
            <text className="tl-label" x="24" y={track.y + 27}>
              {track.label}
            </text>
            {track.clips.map(([x, w]) => {
              const lit = x >= 140 && x <= 700;
              return (
                <rect
                  key={`${track.label}-${x}`}
                  className={lit ? "tl-clip is-lit" : "tl-clip"}
                  x={x}
                  y={track.y + 4}
                  width={w}
                  height="36"
                  rx="4"
                  style={lit ? { animationDelay: `${litDelay(x).toFixed(2)}s` } : undefined}
                />
              );
            })}
          </g>
        ))}
        {/* Drawn at x=140; the CSS animation translates it 560 units to the right. */}
        <g className="tl-playhead">
          <line x1="140" y1="8" x2="140" y2="232" />
          <polygon points="132,0 148,0 140,12" />
        </g>
      </svg>
    </div>
  );
}
