import Link from "next/link";
import { footerNav, siteConfig } from "@/lib/site";
import { CookieSettingsButton } from "@/components/consent/CookieSettingsButton";

export function Footer() {
  return (
    <footer className="site-footer">
      <div className="container">
        <div className="footer-grid">
          <div className="footer-about">
            <p className="brand">
              Assets<span>Ae</span>
            </p>
            <p>{siteConfig.description}</p>
          </div>

          {footerNav.map((group) => (
            <nav key={group.heading} aria-label={group.heading}>
              <h2>{group.heading}</h2>
              <ul>
                {group.links.map((link) => (
                  <li key={link.href}>
                    <Link href={link.href}>{link.label}</Link>
                  </li>
                ))}
                {group.heading === "Legal" ? (
                  <li>
                    <CookieSettingsButton />
                  </li>
                ) : null}
              </ul>
            </nav>
          ))}
        </div>
        <p className="footer-base">© {new Date().getFullYear()} AssetsAe. All rights reserved.</p>
      </div>
    </footer>
  );
}
