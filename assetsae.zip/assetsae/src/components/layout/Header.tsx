import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { NavMenu } from "@/components/layout/NavMenu";

/** Server component: reads the session so the nav shows the right account actions. */
export async function Header() {
  const supabase = await createClient();
  const {
    data: { user },
  } = supabase ? await supabase.auth.getUser() : { data: { user: null } };

  return (
    <header className="site-header">
      <div className="container site-header-inner">
        <Link href="/" className="brand" aria-label="AssetsAe home">
          Assets<span>Ae</span>
        </Link>
        <NavMenu isSignedIn={Boolean(user)} />
      </div>
    </header>
  );
}
