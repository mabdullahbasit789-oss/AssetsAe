"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import {
  OPEN_CONSENT_EVENT,
  optionalCategories,
  readConsent,
  writeConsent,
  type ConsentCategory,
} from "@/lib/consent";
import { Button } from "@/components/ui/Button";

export function CookieBanner() {
  const [visible, setVisible] = useState(false);
  const [choices, setChoices] = useState<Record<ConsentCategory, boolean>>({ analytics: false, marketing: false });
  const headingRef = useRef<HTMLHeadingElement>(null);
  const hasOptional = optionalCategories.length > 0;

  useEffect(() => {
    const existing = readConsent();
    if (!existing) setVisible(true);
    else setChoices(existing.categories);

    const reopen = () => {
      setChoices(readConsent()?.categories ?? { analytics: false, marketing: false });
      setVisible(true);
    };
    window.addEventListener(OPEN_CONSENT_EVENT, reopen);
    return () => window.removeEventListener(OPEN_CONSENT_EVENT, reopen);
  }, []);

  // When reopened from the footer, move focus to the banner so keyboard users land on it.
  useEffect(() => {
    if (visible) headingRef.current?.focus({ preventScroll: false });
  }, [visible]);

  function save(categories: Partial<Record<ConsentCategory, boolean>>) {
    writeConsent(categories);
    setVisible(false);
  }

  if (!visible) return null;

  return (
    <section className="consent" role="region" aria-labelledby="consent-heading">
      <h2 id="consent-heading" ref={headingRef} tabIndex={-1} style={{ fontSize: "var(--text-lg)" }}>
        Cookies on AssetsAe
      </h2>

      {hasOptional ? (
        <>
          <p>
            We use necessary cookies to keep you signed in and remember this choice. With your permission we also use the
            optional cookies below. Nothing optional loads until you say yes. Details are in the{" "}
            <Link href="/cookies">Cookie Policy</Link>.
          </p>
          <fieldset className="consent-options">
            <legend className="sr-only">Optional cookie categories</legend>
            {optionalCategories.map((cat) => (
              <div className="check" key={cat.id}>
                <input
                  id={`consent-${cat.id}`}
                  type="checkbox"
                  checked={choices[cat.id]}
                  onChange={(e) => setChoices((c) => ({ ...c, [cat.id]: e.target.checked }))}
                />
                <label htmlFor={`consent-${cat.id}`}>
                  {cat.label}
                  <small>{cat.description}</small>
                </label>
              </div>
            ))}
          </fieldset>
          <div className="consent-actions">
            <Button variant="secondary" onClick={() => save({})}>
              Reject optional cookies
            </Button>
            <Button variant="secondary" onClick={() => save(choices)}>
              Save my choices
            </Button>
            <Button onClick={() => save({ analytics: true, marketing: true })}>Accept all</Button>
          </div>
        </>
      ) : (
        <>
          <p>
            AssetsAe sets only the cookies it needs to work: one to keep you signed in and one to remember this notice. We do
            not use analytics or advertising cookies. See the <Link href="/cookies">Cookie Policy</Link> for the full list.
          </p>
          <div className="consent-actions">
            <Button onClick={() => save({})}>Close this notice</Button>
          </div>
        </>
      )}
    </section>
  );
}
