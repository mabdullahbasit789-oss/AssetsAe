"use client";

import { OPEN_CONSENT_EVENT } from "@/lib/consent";

/** Footer control that reopens the consent banner so users can change their choice at any time. */
export function CookieSettingsButton() {
  return (
    <button type="button" className="footer-link-button" onClick={() => window.dispatchEvent(new Event(OPEN_CONSENT_EVENT))}>
      Cookie settings
    </button>
  );
}
