import type { ReactNode } from "react";

type SectionProps = {
  id: string;
  title: string;
  intro?: string;
  children: ReactNode;
  footer?: ReactNode;
};

/** One section, one focus. Centered heading block with an accessible name. */
export function Section({ id, title, intro, children, footer }: SectionProps) {
  const headingId = `${id}-heading`;
  return (
    <section id={id} aria-labelledby={headingId} className="section">
      <div className="container">
        <header className="section-header">
          <h2 id={headingId}>{title}</h2>
          {intro ? <p>{intro}</p> : null}
        </header>
        {children}
        {footer ? <div className="section-footer">{footer}</div> : null}
      </div>
    </section>
  );
}
