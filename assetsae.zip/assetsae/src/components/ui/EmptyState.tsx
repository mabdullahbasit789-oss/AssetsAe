import { ButtonLink } from "@/components/ui/Button";

type EmptyStateProps = {
  title: string;
  /** Say what will appear here and when. */
  description: string;
  action?: { label: string; href: string };
};

export function EmptyState({ title, description, action }: EmptyStateProps) {
  return (
    <div className="empty-state">
      <h3>{title}</h3>
      <p>{description}</p>
      {action ? (
        <ButtonLink href={action.href} variant="secondary">
          {action.label}
        </ButtonLink>
      ) : null}
    </div>
  );
}
