import Link from "next/link";
import type { ReactNode } from "react";

type CardProps = {
  title: string;
  /** What it is. */
  description: string;
  /** Why it matters to the editor. */
  benefit: string;
  /** What the user can do next. Required: a card without an action is not allowed. */
  action: { label: string; href: string };
  /** Optional small line above the title, such as a status or category. */
  meta?: string;
  headingLevel?: 2 | 3 | 4;
  media?: ReactNode;
};

/**
 * The only card component. Its props enforce the design rule that every card
 * says what it is, why it matters and what to do next.
 */
export function Card({ title, description, benefit, action, meta, headingLevel = 3, media }: CardProps) {
  const Heading = `h${headingLevel}` as "h2" | "h3" | "h4";
  return (
    <article className="card">
      {media ? <div className="card-media">{media}</div> : null}
      {meta ? <p className="card-meta">{meta}</p> : null}
      <Heading>{title}</Heading>
      <p className="card-description">{description}</p>
      <p className="card-benefit">{benefit}</p>
      <p className="card-action">
        <Link href={action.href}>{action.label}</Link>
      </p>
    </article>
  );
}
