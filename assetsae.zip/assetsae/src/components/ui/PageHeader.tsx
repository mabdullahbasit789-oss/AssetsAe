import type { ReactNode } from "react";

type PageHeaderProps = { title: string; intro?: string; children?: ReactNode };

export function PageHeader({ title, intro, children }: PageHeaderProps) {
  return (
    <header className="page-header">
      <div className="container">
        <div className="page-header-inner">
          <h1>{title}</h1>
          {intro ? <p>{intro}</p> : null}
          {children}
        </div>
      </div>
    </header>
  );
}
