import type { ReactNode } from "react";
import { PageHeader } from "@/components/ui/PageHeader";
import { siteConfig } from "@/lib/site";

type LegalPageProps = { title: string; intro: string; children: ReactNode };

/** Shared shell for legal documents. Shows the version date and the review notice. */
export function LegalPage({ title, intro, children }: LegalPageProps) {
  return (
    <>
      <PageHeader title={title} intro={intro} />
      <div className="container">
        <div className="legal">
          <p className="legal-notice">
            Version {siteConfig.legalVersion}. This document is a working draft written for the current phase of AssetsAe and
            must be reviewed by a qualified lawyer before the site launches publicly.
          </p>
          {children}
          <h2>Contact</h2>
          {siteConfig.contactEmail ? (
            <p>
              Questions about this document: <a href={`mailto:${siteConfig.contactEmail}`}>{siteConfig.contactEmail}</a>.
            </p>
          ) : (
            <p>A contact address will be published here before launch.</p>
          )}
        </div>
      </div>
    </>
  );
}
