import type { AssetCategorySlug } from "@/lib/site";

/** Shapes the UI works with. Mapped from database rows in src/lib/data. */

export type Asset = {
  id: string;
  slug: string;
  title: string;
  description: string;
  category: AssetCategorySlug;
  software: string[];
  previewUrl: string | null;
  license: { slug: string; name: string; summary: string | null; termsUrl: string | null } | null;
  creator: { username: string | null; displayName: string | null } | null;
};

export type Creator = {
  id: string;
  username: string | null;
  displayName: string | null;
  bio: string | null;
  youtubeUrl: string | null;
};

export type Tutorial = {
  id: string;
  slug: string;
  track: string;
  title: string;
  summary: string;
};

export type LibraryCounts = {
  saved: number;
  downloads: number;
  creations: number;
  collections: number;
};
