/**
 * Single source of truth for site-wide content that more than one component needs:
 * navigation, categories, AI tools, learning tracks and team.
 * Pages and the footer read from here so labels never drift.
 */

export const siteConfig = {
  name: "AssetsAe",
  tagline: "Assets, tools and lessons for video editors",
  description:
    "AssetsAe is a workspace for video editors: licensed assets, AI-assisted tools, tutorials and a personal cloud library.",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000",
  contactEmail: process.env.NEXT_PUBLIC_CONTACT_EMAIL || null,
  /** Bump when the legal documents change materially. Stored with each consent record. */
  legalVersion: "2026-11-22",
} as const;

export type NavItem = { label: string; href: string };

export const primaryNav: NavItem[] = [
  { label: "Assets", href: "/assets" },
  { label: "AI Tools", href: "/ai-tools" },
  { label: "Learn", href: "/learn" },
  { label: "Library", href: "/library" },
  { label: "Community", href: "/community" },
];

export const footerNav: { heading: string; links: NavItem[] }[] = [
  {
    heading: "Platform",
    links: [
      { label: "Assets", href: "/assets" },
      { label: "AI Tools", href: "/ai-tools" },
      { label: "Learn", href: "/learn" },
      { label: "Cloud Library", href: "/library" },
      { label: "Community", href: "/community" },
    ],
  },
  {
    heading: "Company",
    links: [{ label: "About and team", href: "/about" }],
  },
  {
    heading: "Legal",
    links: [
      { label: "Privacy Policy", href: "/privacy" },
      { label: "Terms of Service", href: "/terms" },
      { label: "Cookie Policy", href: "/cookies" },
      { label: "Refund Policy", href: "/refunds" },
    ],
  },
];

/* ---------- Asset categories ---------- */

export const assetCategories = [
  {
    slug: "clips",
    name: "Video clips",
    description: "Stock footage and b-roll you can cut straight into a timeline.",
    benefit: "Fills gaps in an edit without a reshoot. Each clip lists its resolution and license.",
  },
  {
    slug: "overlays",
    name: "Overlays",
    description: "Light leaks, dust, film grain, glitches and other layers that sit on top of footage.",
    benefit: "Adds texture in one drag-and-drop step. Blend mode suggestions are listed per file.",
  },
  {
    slug: "effects",
    name: "Effects",
    description: "Reusable effect setups and project files for After Effects, Alight Motion and similar editors.",
    benefit: "Skip rebuilding the same look. Open the project and see exactly how it was made.",
  },
  {
    slug: "presets",
    name: "Presets",
    description: "Saved settings for motion, text, transitions and looks.",
    benefit: "Apply a tested starting point, then adjust it to your shot.",
  },
  {
    slug: "luts",
    name: "LUTs",
    description: "Colour lookup tables for grading and for converting between camera profiles.",
    benefit: "Get consistent colour across clips. Notes say which footage each LUT was built for.",
  },
  {
    slug: "templates",
    name: "Templates",
    description: "Complete project files for intros, lower thirds, title sequences and social formats.",
    benefit: "Start from a structured project and replace the content with your own.",
  },
  {
    slug: "audio",
    name: "Audio",
    description: "Sound effects, music and ambience with clear usage terms.",
    benefit: "Know before you publish whether a track is safe for monetised videos.",
  },
  {
    slug: "stickers",
    name: "Emojis and stickers",
    description: "Transparent PNG and animated sticker packs for overlays and captions.",
    benefit: "Drop-in graphics that keep their transparency in any editor.",
  },
  {
    slug: "other",
    name: "Other resources",
    description: "Fonts, shape packs, brushes and anything else an editor might reach for.",
    benefit: "Keeps useful odds and ends in one searchable place.",
  },
] as const;

export type AssetCategorySlug = (typeof assetCategories)[number]["slug"];

export function getCategory(slug: string) {
  return assetCategories.find((c) => c.slug === slug) ?? null;
}

/* ---------- AI tools (all in planning) ---------- */

export const aiTools = [
  {
    slug: "effect-creator",
    name: "AI Effect Creator",
    description: "Describe an effect in plain language and get a step-by-step build for your editor.",
    benefit: "Shortens the trial and error of working out which layers and settings produce a look.",
    status: "In planning",
  },
  {
    slug: "preset-converter",
    name: "AI Preset Converter",
    description: "Translate preset settings from one editor to another where the formats allow it.",
    benefit: "Reuse work you already own when you change tools. Anything that cannot be converted is flagged.",
    status: "In planning",
  },
  {
    slug: "style-analyzer",
    name: "AI Style Analyzer",
    description: "Upload a reference frame or clip and get notes on its colour, contrast and motion style.",
    benefit: "Turns a vague 'make it look like this' into settings you can try.",
    status: "In planning",
  },
  {
    slug: "asset-finder",
    name: "AI Asset Finder",
    description: "Search the library by describing the shot or mood you need.",
    benefit: "Finds assets by meaning, so you do not have to guess the right tag.",
    status: "In planning",
  },
  {
    slug: "editing-assistant",
    name: "AI Editing Assistant",
    description: "A chat assistant that answers editing questions and suggests techniques.",
    benefit: "Quick, friendly help when you are stuck mid-edit.",
    status: "In planning",
  },
] as const;

/* ---------- Learning tracks ---------- */

export const learningTracks = [
  {
    slug: "after-effects",
    dbValue: "after_effects",
    name: "After Effects",
    description: "Compositing, expressions, shape layers and motion graphics workflows.",
    benefit: "Build skills on the industry-standard tool, from first comp to reusable templates.",
  },
  {
    slug: "alight-motion",
    dbValue: "alight_motion",
    name: "Alight Motion",
    description: "Mobile motion graphics: keyframes, effects, blending and exporting.",
    benefit: "Get desktop-quality results from a phone.",
  },
  {
    slug: "editing-techniques",
    dbValue: "editing_techniques",
    name: "Editing techniques",
    description: "Pacing, cuts, transitions, sound design and storytelling.",
    benefit: "Skills that carry over to any editor.",
  },
  {
    slug: "effects-tutorials",
    dbValue: "effects_tutorials",
    name: "Effects tutorials",
    description: "Step-by-step recreations of popular looks with the project files attached.",
    benefit: "Learn by taking a finished effect apart.",
  },
  {
    slug: "color-grading",
    dbValue: "color_grading",
    name: "Color grading",
    description: "Exposure, white balance, curves, LUT use and matching shots.",
    benefit: "Make footage from different cameras look like one film.",
  },
] as const;

export function getTrack(slug: string) {
  return learningTracks.find((t) => t.slug === slug) ?? null;
}

/* ---------- Team ---------- */

export const team = [
  {
    name: "Pixel Edits",
    role: "CEO and Founder",
    bio: "Leads product direction for AssetsAe.",
    youtubeUrl: null as string | null, // Official link will be added later.
  },
  {
    name: "Total Edits OP",
    role: "Close collaborator and friend of the CEO",
    bio: "Works alongside the founder on the creative side of the platform.",
    youtubeUrl: null as string | null, // Official link will be added later.
  },
];
