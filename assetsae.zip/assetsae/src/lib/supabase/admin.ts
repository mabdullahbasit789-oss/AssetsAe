import "server-only";
import { createClient } from "@supabase/supabase-js";
import { getServiceRoleEnv } from "@/lib/env";

/**
 * Service-role client. Bypasses Row Level Security.
 * Server only. Use for account deletion and signed download URLs, never for
 * reads that a signed-in user could do through the normal client.
 */
export function createAdminClient() {
  const env = getServiceRoleEnv();
  if (!env) return null;
  return createClient(env.url, env.serviceRoleKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
}
