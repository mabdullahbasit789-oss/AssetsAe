import { createClient } from "@/lib/supabase/server";
import type { LibraryCounts } from "@/types/domain";

/** Item counts for the signed-in user's cloud library. RLS limits every table to the caller's rows. */
export async function getLibraryCounts(): Promise<LibraryCounts | null> {
  const supabase = await createClient();
  if (!supabase) return null;

  const count = (table: string) => supabase.from(table).select("*", { count: "exact", head: true });

  const [saved, downloads, creations, collections] = await Promise.all([
    count("saved_assets"),
    count("downloads"),
    count("user_creations"),
    count("collections"),
  ]);

  const firstError = [saved, downloads, creations, collections].find((r) => r.error)?.error;
  if (firstError) {
    console.error("getLibraryCounts failed", firstError.message);
    return null;
  }

  return {
    saved: saved.count ?? 0,
    downloads: downloads.count ?? 0,
    creations: creations.count ?? 0,
    collections: collections.count ?? 0,
  };
}
