import { createClient } from "@/lib/supabase/server";
import { BUCKETS, publicStorageUrl } from "@/lib/storage";
import type { AssetCategorySlug } from "@/lib/site";
import type { Asset, Creator } from "@/types/domain";

/**
 * Read-only catalog queries. Each returns an empty result (never throws) when
 * Supabase is not configured or the query fails, so pages can show an honest
 * empty state instead of crashing. Failures are logged on the server.
 */

const ASSET_COLUMNS = `
  id, slug, title, description, category, software, preview_path,
  license:licenses ( slug, name, summary, terms_url ),
  creator:profiles ( username, display_name )
`;

type Joined<T> = T | T[] | null;

function one<T>(value: Joined<T>): T | null {
  if (Array.isArray(value)) return value[0] ?? null;
  return value ?? null;
}

// Row shape returned by ASSET_COLUMNS. The client is untyped until `supabase gen types` is wired in.
type AssetRow = {
  id: string;
  slug: string;
  title: string;
  description: string | null;
  category: AssetCategorySlug;
  software: string[] | null;
  preview_path: string | null;
  license: Joined<{ slug: string; name: string; summary: string | null; terms_url: string | null }>;
  creator: Joined<{ username: string | null; display_name: string | null }>;
};

function toAsset(row: AssetRow): Asset {
  const license = one(row.license);
  const creator = one(row.creator);
  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    description: row.description ?? "",
    category: row.category,
    software: row.software ?? [],
    previewUrl: publicStorageUrl(BUCKETS.previews, row.preview_path),
    license: license
      ? { slug: license.slug, name: license.name, summary: license.summary, termsUrl: license.terms_url }
      : null,
    creator: creator ? { username: creator.username, displayName: creator.display_name } : null,
  };
}

export async function getFeaturedAssets(limit = 6): Promise<Asset[]> {
  const supabase = await createClient();
  if (!supabase) return [];
  const { data, error } = await supabase
    .from("assets")
    .select(ASSET_COLUMNS)
    .eq("status", "published")
    .eq("is_featured", true)
    .order("published_at", { ascending: false })
    .limit(limit);
  if (error) {
    console.error("getFeaturedAssets failed", error.message);
    return [];
  }
  return ((data ?? []) as unknown as AssetRow[]).map(toAsset);
}

export async function getAssetsByCategory(category: AssetCategorySlug, limit = 48): Promise<Asset[]> {
  const supabase = await createClient();
  if (!supabase) return [];
  const { data, error } = await supabase
    .from("assets")
    .select(ASSET_COLUMNS)
    .eq("status", "published")
    .eq("category", category)
    .order("published_at", { ascending: false })
    .limit(limit);
  if (error) {
    console.error("getAssetsByCategory failed", error.message);
    return [];
  }
  return ((data ?? []) as unknown as AssetRow[]).map(toAsset);
}

export async function getAsset(category: AssetCategorySlug, slug: string): Promise<Asset | null> {
  const supabase = await createClient();
  if (!supabase) return null;
  const { data, error } = await supabase
    .from("assets")
    .select(ASSET_COLUMNS)
    .eq("status", "published")
    .eq("category", category)
    .eq("slug", slug)
    .maybeSingle();
  if (error) {
    console.error("getAsset failed", error.message);
    return null;
  }
  return data ? toAsset(data as unknown as AssetRow) : null;
}

export async function getFeaturedCreators(limit = 6): Promise<Creator[]> {
  const supabase = await createClient();
  if (!supabase) return [];
  const { data, error } = await supabase
    .from("profiles")
    .select("id, username, display_name, bio, youtube_url")
    .eq("is_creator", true)
    .eq("is_featured", true)
    .limit(limit);
  if (error) {
    console.error("getFeaturedCreators failed", error.message);
    return [];
  }
  return (data ?? []).map((r) => ({
    id: r.id as string,
    username: (r.username as string | null) ?? null,
    displayName: (r.display_name as string | null) ?? null,
    bio: (r.bio as string | null) ?? null,
    youtubeUrl: (r.youtube_url as string | null) ?? null,
  }));
}
