/**
 * Cookie consent model.
 *
 * Today AssetsAe sets only strictly necessary cookies (sign-in session and the
 * consent record itself), which do not need opt-in. The banner is still shown
 * so visitors can read what is set. If analytics or marketing tools are ever
 * added, register them in `optionalCategories`: the banner then shows equal
 * "Accept" and "Reject" buttons and per-category choices, and nothing
 * optional may load until `hasConsent(category)` is true.
 */

export const CONSENT_VERSION = 1;
export const CONSENT_COOKIE = "assetsae_consent";
export const CONSENT_MAX_AGE_SECONDS = 60 * 60 * 24 * 180; // 180 days
export const OPEN_CONSENT_EVENT = "assetsae:open-consent";

export type ConsentCategory = "analytics" | "marketing";

export type OptionalCategory = { id: ConsentCategory; label: string; description: string };

/** Intentionally empty. Add an entry here before adding any optional third-party tool. */
export const optionalCategories: OptionalCategory[] = [];

export type ConsentState = {
  version: number;
  decidedAt: string;
  categories: Record<ConsentCategory, boolean>;
};

const OFF: Record<ConsentCategory, boolean> = { analytics: false, marketing: false };

export function readConsent(): ConsentState | null {
  if (typeof document === "undefined") return null;
  const raw = document.cookie
    .split("; ")
    .find((c) => c.startsWith(`${CONSENT_COOKIE}=`))
    ?.slice(CONSENT_COOKIE.length + 1);
  if (!raw) return null;
  try {
    const parsed = JSON.parse(decodeURIComponent(raw)) as ConsentState;
    if (parsed.version !== CONSENT_VERSION) return null; // re-ask when the model changes
    return { ...parsed, categories: { ...OFF, ...parsed.categories } };
  } catch {
    return null;
  }
}

export function writeConsent(categories: Partial<Record<ConsentCategory, boolean>>): ConsentState {
  const state: ConsentState = {
    version: CONSENT_VERSION,
    decidedAt: new Date().toISOString(),
    categories: { ...OFF, ...categories },
  };
  const secure = window.location.protocol === "https:" ? "; Secure" : "";
  document.cookie = `${CONSENT_COOKIE}=${encodeURIComponent(JSON.stringify(state))}; Path=/; Max-Age=${CONSENT_MAX_AGE_SECONDS}; SameSite=Lax${secure}`;
  return state;
}

export function hasConsent(category: ConsentCategory): boolean {
  return readConsent()?.categories[category] === true;
}
