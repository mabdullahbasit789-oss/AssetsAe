export const BUCKETS = {
  previews: "asset-previews", // public, safe to hotlink
  files: "asset-files", // private, served through signed URLs
  avatars: "avatars", // public
} as const;

/** Public URL for an object in a public bucket. Returns null when there is no path or no project. */
export function publicStorageUrl(bucket: string, path: string | null | undefined): string | null {
  const base = process.env.NEXT_PUBLIC_SUPABASE_URL;
  if (!base || !path) return null;
  return `${base}/storage/v1/object/public/${bucket}/${path}`;
}
