# AssetsAe

An AI-powered creative asset platform for video editors. This is the phase 1 foundation: project structure, design system, core pages, legal and consent basics, and the Supabase schema.

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for decisions and structure.

## Run it

```bash
npm install
cp .env.example .env.local   # fill in Supabase values
npm run dev
```

The site renders without Supabase configured (catalog sections show empty states). Sign-in, the library and account deletion need a project.

## Connect Supabase

1. Create a Supabase project.
2. Run `supabase/migrations/0001_foundation.sql` in the SQL editor (or with the Supabase CLI).
3. Add the project URL, anon key and service role key to `.env.local`. The service role key is server only.
4. In Authentication settings, set the site URL and add `<site url>/auth/callback` as a redirect URL.
5. Add at least one row to `licenses`, then mark a profile `is_creator = true` to start publishing test assets from the dashboard.

## Scripts

- `npm run dev` start the dev server
- `npm run build` production build
- `npm run typecheck` TypeScript check

## Before launch

- Have a lawyer review the Privacy Policy, Terms, Cookie Policy and Refund Policy.
- Set `NEXT_PUBLIC_CONTACT_EMAIL` and add the official YouTube links in `src/lib/site.ts`.
- Choose a hosting provider and name it in the Privacy Policy.
- Only publish assets you have the right to distribute, each with a license.
