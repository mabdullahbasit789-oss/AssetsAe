# AssetsAe architecture (phase 1)

## Goals for this phase

Build the foundation only: structure, navigation, core pages, design system, reusable components, and a Supabase and database plan that later phases can build on without rewrites.

## Decisions and why

| Decision | Reason |
| --- | --- |
| **Next.js (App Router) + TypeScript** | Server rendering for SEO on a public catalog, React components, route handlers for server-only work, one deployable. |
| **Supabase** (Auth, Postgres, Storage) | Covers auth, data, files and per-user libraries in one managed service with Row Level Security. |
| **`@supabase/ssr` with cookie sessions** | Sessions work in Server Components and middleware. The middleware refreshes the session and guards `/library` and `/account`. |
| **RLS on every table, deny by default** | The anon key is public by design, so the database enforces access, not the app. Users can only read and write their own library rows. |
| **Column-level grants** | Users cannot set `is_creator`, `is_featured`, or publish an asset. Those are admin-only (service role or dashboard). |
| **Plain CSS with design tokens** | No UI library to audit, no generic template look. Tokens live in `src/styles/tokens.css`; all spacing is a multiple of 4px. |
| **Manrope + JetBrains Mono via `next/font`** | Professional, not Inter. Fonts are fetched at build time and self-hosted, so visitors make no request to Google. |
| **Content config in `src/lib/site.ts`** | Navigation, categories, AI tools, tracks and team have one source, so labels never drift between pages and footer. |
| **Honest empty states** | No seed data and no placeholder numbers. Pages query Supabase and show what will appear when it is empty. |
| **Config-driven consent** | `src/lib/consent.ts` lists optional cookie categories (currently none). Adding analytics later forces a consent UI change in the same place. |

## Folder structure

```
src/
  app/                    Routes (App Router)
    page.tsx              Home
    assets/               Library: category index, category page, asset detail
    ai-tools/             Planned AI tools
    learn/                Learning center: index and track pages
    library/              Cloud library (auth required)
    community/            Creators
    about/                Mission and team
    login, signup/        Auth forms
    account/privacy/      Data overview and account deletion
    privacy, terms, cookies, refunds/   Legal pages
    auth/callback, auth/signout/        Auth route handlers
    api/account/delete/   Server-side account and file deletion
  components/
    ui/                   Button, Card, Section, PageHeader, EmptyState
    layout/               Header (server), NavMenu (client), Footer
    consent/              CookieBanner, CookieSettingsButton
    auth/                 AuthForm, DeleteAccountForm
    assets/               AssetCard
    home/                 Timeline (hero illustration)
    legal/                LegalPage shell
  lib/
    site.ts               Navigation, categories, AI tools, tracks, team, legal version
    env.ts                Environment access, Supabase optional at build time
    consent.ts            Cookie consent model
    storage.ts            Bucket names and public URL helper
    ai/persona.ts         Assistant system prompt
    data/                 Catalog and library queries
    supabase/             Browser, server, admin and middleware clients
  styles/                 tokens, base, components, pages
  types/domain.ts         UI-facing types
supabase/migrations/      SQL schema, RLS and storage policies
docs/                     This file
```

## Data model

- **profiles**: one per user, minimal fields. `is_creator` and `is_featured` are admin-controlled.
- **licenses**: every asset references one. Shown before download.
- **assets**: category enum covers clips, overlays, effects, presets, LUTs, templates, audio, stickers, other. Status flow: draft, in_review, published, archived. Creators can only reach draft or in_review.
- **saved_assets, downloads, collections, collection_items, user_creations**: the cloud library. Downloads store the license that applied at the time.
- **tutorials, tutorial_assets**: learning content tied to the five tracks and to the assets each lesson uses.
- **consent_records**: append-only proof of the terms version and optional consents accepted.

Storage buckets: `asset-previews` (public), `asset-files` (private, signed URLs only), `avatars` (public). Objects are stored under `<user id>/...` so policies and account deletion can target them.

## Privacy and trust, as built

- Sign-up has an unchecked required box for Terms and Privacy and a separate unchecked optional box for product emails. A database trigger records both.
- Account deletion is self-serve: `/account/privacy` calls `/api/account/delete`, which removes the user's storage objects and then the auth user. Rows cascade.
- Only strictly necessary cookies are set. The banner states this and can be reopened from the footer.
- No analytics, ads or tracking SDKs are installed.
- Legal pages are drafts and carry a visible notice. They need lawyer review before launch.

## Third-party audit

| Service | Why | Data it handles |
| --- | --- | --- |
| Supabase | Auth, database, storage | Email, hashed password, profile, library, uploads |
| Hosting provider (not yet chosen) | Serve the site | Request logs |
| Google Fonts | Build-time font download only | None from visitors |

Add any new service to this table, to the Privacy Policy and, if it sets optional cookies, to `optionalCategories`, before enabling it.

## Not built yet (later phases)

1. Creator upload and review flow, admin publishing tools.
2. Save, download (signed URLs plus a `downloads` insert) and collections UI.
3. Search and filters, then semantic search for the AI Asset Finder.
4. AI tools and the assistant, using `src/lib/ai/persona.ts` as the system prompt.
5. Tutorials content, payments (and a real Refund Policy), creator pages.
6. Generated Supabase types (`supabase gen types`) to replace the hand-mapped rows in `src/lib/data`.
7. Tests, CI, error monitoring (audit before adding), a cookie-less client for cached public catalog queries.
